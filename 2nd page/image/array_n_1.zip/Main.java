import java.io.File;
import java.util.Scanner;

public class Main {

    public static void printArray(int[][] array) {
        if (array == null) {
            System.out.println("null");
            return;
        }
        for (int[] row : array) {
            for (int value : row) {
                System.out.printf("%5d", value);
            }
            System.out.println();
        }
    }
    public static int[][] createArray(int rows, int cols, int min, int max) {
        int[][] array = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                array[i][j] = (int) (Math.random() * (max - min + 1)) + min;
            }
        }
        return array;
    }
    public static int[][] createArray() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите количество строк: ");
        int rows = scanner.nextInt();
        System.out.print("Введите количество столбцов: ");
        int cols = scanner.nextInt();

        int[][] array = new int[rows][cols];
        System.out.println("Введите элементы массива:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                array[i][j] = scanner.nextInt();
            }
        }
        return array;
    }
    public static int[][] createArray(String filename) {
        File file = new File(filename);
        if (!file.exists()) {
            return null;
        }
        Scanner scanner = null;
        try {
            scanner = new Scanner(file);
        } catch (Exception e) {
            return null;
        }
        if (!scanner.hasNextInt()) {
            scanner.close();
            return null;
        }
        int rows = scanner.nextInt();
        if (!scanner.hasNextInt()) {
            scanner.close();
            return null;
        }
        int cols = scanner.nextInt();
        int[][] array = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (scanner.hasNextInt()) {
                    array[i][j] = scanner.nextInt();
                } else {
                    array[i][j] = 0;
                }
            }
        }
        scanner.close();
        return array;
    }
    public static void main(String[] args) {
        int[][] a1 = createArray(5, 8, -10, 9);
        System.out.println("Массив 1:");
        printArray(a1);
        int[][] a2 = createArray();
        System.out.println("Массив 2:");
        printArray(a2);
        int[][] a3 = createArray("data.txt");
        System.out.println("Массив 3:");
        printArray(a3);
    }
}